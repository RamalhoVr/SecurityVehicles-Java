package SecurityVehicles;

public abstract class Vehicles {

	// Static variable to store the security price
	static double PriceSecurity;
	
	// Instance variables
	String Color;
	String Plate;
	String Chassis;
	String Propierty;
	static int Age;
	
	// Default constructor
	public Vehicles() {}
	
	// Abstract method to calculate the security price
	public double CalculeSecurity() {
		return 0;
	}
}
