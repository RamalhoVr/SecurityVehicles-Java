package SecurityVehicles;

public class Car extends Vehicles{

	// Boolean variable to indicate if the car has a step
	boolean step;
	
	// Default constructor
	public Car() {
		super();
	}

	// Method to calculate the security price for a car based on the age
	public double CalculateSecurity(int Age) {

		// Calculate the security price based on the age
		if (Age == 18) {
			super.PriceSecurity = 5228.87 * 1.075;
		}
		else if (Age > 18) {
			super.PriceSecurity = 2851.75 * 1.15;	
		}
		else if (Age > 30 && Age < 50) {
			super.PriceSecurity = 3041.78 * 1.25;
		}
		else if (Age < 18) {
			super.PriceSecurity = 1;
		}
		else {
			super.PriceSecurity = 3365.15 * 1.30;
		}
		
		// Return the calculated security price
		return PriceSecurity;
	}

}
