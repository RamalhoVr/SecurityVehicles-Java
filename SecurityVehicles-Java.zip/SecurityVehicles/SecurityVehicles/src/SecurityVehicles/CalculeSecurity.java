package SecurityVehicles;

import javax.swing.JOptionPane;

public class CalculeSecurity {

	public static void main(String[] args) {
		
		String option;
		int age;
		
		// Create objects of Car and Motocycle classes
		Car car = new Car();
		Motocycle motocycle = new Motocycle();

		// Ask for user input
		option = JOptionPane.showInputDialog("Which type of vehicle are you getting?");
		age = Integer.parseInt(JOptionPane.showInputDialog("What is your age?"));
		Vehicles.Age = age; // Set the age for the Vehicles class

		// Check the user's option and calculate the security price accordingly
		if (option.equalsIgnoreCase("car")) {
			System.out.println(car.CalculateSecurity(Vehicles.Age));
		}
		else if(option.equalsIgnoreCase("motorcycle")) {
			System.out.println(motocycle.CalculateSecurity(Vehicles.Age));
		}
		else {
			System.out.println("Invalid option. Please run it again.");
		}

		// Display the calculated security price to the user
		JOptionPane.showMessageDialog(null, "The price you will need to pay is: " + Vehicles.PriceSecurity);
	}
}
