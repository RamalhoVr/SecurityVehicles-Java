package SecurityVehicles;
public class SwitchVehicles {

	// Method that calculates the security price for a vehicle
	public double CalculateSecurity(Vehicles vehicles) {
		return vehicles.CalculeSecurity();
	}
	
}
