package SecurityVehicles;

public class Motocycle extends Vehicles {
	
	// Boolean variable to indicate if the motorcycle has a SissyBar
	boolean SissyBar;
	
	// Default constructor
	public Motocycle() {
		super();
	}

	// Method to calculate the security price for a motorcycle based on the age
	public double CalculateSecurity(int Age) {

		// Calculate the security price based on the age
		if (Age == 18) {
			super.PriceSecurity = 5228.87 * 1.12;
		}
		else if (Age > 18) {
			super.PriceSecurity = 2851.75 * 1.20;	
		}
		else if (Age > 30 && Age < 50) {
			super.PriceSecurity = 3041.78 * 1.15;
		}
		else if (Age < 18) {
			super.PriceSecurity = 1;
		}
		else {
			super.PriceSecurity = 3365.15 * 1.10;
		}
		
		// Return the calculated security price
		return PriceSecurity;
	}

}
